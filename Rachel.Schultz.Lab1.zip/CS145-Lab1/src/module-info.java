module uwstout.courses.cs145.labs.lab01 {
	requires junit;
	exports uwstout.courses.cs145.labs.lab01;
}