module uwstout.courses.cs145.labs.lab02 {
	requires junit;
}