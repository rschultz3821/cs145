module uwstout.courses.cs145.projects.chessgame {
	
	exports uwstout.courses.cs145.projects.chessgame;
	requires junit;
}