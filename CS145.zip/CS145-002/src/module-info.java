module uwstout.courses.cs145 {
	
	requires junit;
	
}